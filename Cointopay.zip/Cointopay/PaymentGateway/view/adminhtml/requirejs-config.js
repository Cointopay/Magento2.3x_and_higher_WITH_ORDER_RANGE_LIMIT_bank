var config = {
    config: {
        mixins: {
            'mage/validation': {
                'CointopayBank_PaymentGateway/js/admin-config/validator-rules-mixin': true
            }
        }
    }
};